﻿using Fitness.Controllers;
using Fitness.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Fitness.MSTest.E2E
{
    [TestClass]
    public class FitnessE2ETests
    {
        [TestMethod]
        public void TestFitnessApplication()
        {
            // Arrange
            var rnd = new Random();
            
            // user
            var userName = Guid.NewGuid().ToString();
            var genderName = Guid.NewGuid().ToString();
            var gender = new Gender(genderName);
            var birthday = DateTime.Now.AddYears(-18);
            var weight = 90;
            var height = 190;
            var user = new User(userName, gender, birthday, weight, height);
            var userController = new UserController(userName);
            UserController userController2;

            // food
            var eatingController = new EatingController(userController.CurrentUser);
            var food1 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood1") ?? new Food("TestFood1");
            var food2 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood2") ?? new Food("TestFood2");
            var food3 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood3") ?? new Food("TestFood3");
            var food4 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood4") ?? new Food("TestFood4");
            var food5 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood5") ?? new Food("TestFood5");
            var eating = eatingController.Eating;
            var food1Exists = false;
            var food2Exists = false;
            var food3Exists = false;
            var food4Exists = false;
            var food5Exists = false;

            // exercise
            var exerciseController = new ExerciseController(userController.CurrentUser);
            var activityName = Guid.NewGuid().ToString();
            var caloriesPerMinute = 12;
            var activity = new Activity(activityName, caloriesPerMinute);
            var beginTime = DateTime.Now;
            var endTime = DateTime.Now.AddHours(1);










            // Act
            // user
            userController.SetNewUserData(genderName, birthday, weight, height);
            userController2 = new UserController(userName);

            // food
            eatingController.Add(food1, 150);
            eatingController.Add(food2, 120);
            eatingController.Add(food3, 170);
            eatingController.Add(food4, 190);
            eatingController.Add(food5, 290);

            food1Exists = eating.Foods.TryGetValue(food1, out var quantity1);
            food2Exists = eating.Foods.TryGetValue(food2, out var quantity2);
            food3Exists = eating.Foods.TryGetValue(food3, out var quantity3);
            food4Exists = eating.Foods.TryGetValue(food4, out var quantity4);
            food5Exists = eating.Foods.TryGetValue(food5, out var quantity5);

            // exercise
            exerciseController.Add(activity, beginTime, endTime);










            // Assert
            // user
            Assert.IsNotNull(userController.Users.Find(u => u.Name == userName));
            Assert.AreEqual(userName, userController2.CurrentUser.Name);
            Assert.AreEqual(birthday, userController2.CurrentUser.Birthday);
            Assert.AreEqual(weight, userController2.CurrentUser.Weight);
            Assert.AreEqual(height, userController2.CurrentUser.Height);
            Assert.AreEqual(genderName, userController2.CurrentUser.Gender.Name);

            // food
            Assert.IsTrue(food1Exists, $"Food '{food1.Name}' not found in the dictionary.");
            Assert.AreEqual(150, quantity1);
            Assert.IsTrue(food2Exists, $"Food '{food2.Name}' not found in the dictionary.");
            Assert.AreEqual(120, quantity2);
            Assert.IsTrue(food3Exists, $"Food '{food3.Name}' not found in the dictionary.");
            Assert.AreEqual(170, quantity3);
            Assert.IsTrue(food4Exists, $"Food '{food4.Name}' not found in the dictionary.");
            Assert.AreEqual(190, quantity4);
            Assert.IsTrue(food5Exists, $"Food '{food5.Name}' not found in the dictionary.");
            Assert.AreEqual(290, quantity5);

            // exersice
            Assert.AreEqual(activity, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Activity);
            Assert.AreEqual(activityName, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Activity.Name);
            Assert.AreEqual(caloriesPerMinute, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Activity.CaloriesPerMinute);
            Assert.AreEqual(user.Name, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).User.Name);
            Assert.AreEqual(beginTime, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Start);
            Assert.AreEqual(endTime, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Finish);
        }
    }
}
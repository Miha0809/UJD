﻿using Fitness.Controllers;
using Fitness.Models;
using System;

namespace Fitness
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter name: ");
            var name = Console.ReadLine();

            var userController = new UserController(name);
            var eatingController = new EatingController(userController.CurrentUser);
            var exerciseController = new ExerciseController(userController.CurrentUser);

            if (userController.IsNewUser)
            {
                Console.Write("Enter gender: ");
                var gender = Console.ReadLine();
                var birthDate = ParseDateTime("Birthday");
                var weight = ParseDouble("weight");
                var height = ParseDouble("height");

                userController.SetNewUserData(gender, birthDate, weight, height);
            }

            Console.WriteLine(userController.CurrentUser);

            while (true)
            {
                Console.WriteLine("What do you want to do?");
                Console.WriteLine("A - introduce a meal");
                Console.WriteLine("B - enter exercise");
                Console.WriteLine("C - show meal");
                Console.WriteLine("D - show exercise");
                Console.WriteLine("Q - exit");
                var key = Console.ReadKey();

                Console.WriteLine();

                switch (key.Key)
                {
                    case ConsoleKey.A:
                        var foods = EnterEating();
                        eatingController.Add(foods.Food, foods.Weight);
                        break;
                    case ConsoleKey.B:
                        var exe = EnterExercise();

                        exerciseController.Add(exe.Activity, exe.Begin, exe.End);
                        break;
                    case ConsoleKey.C:

                        foreach (var item in eatingController.Foods)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case ConsoleKey.D:
                        foreach (var item in exerciseController.Exercises)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case ConsoleKey.Q:
                        Environment.Exit(0);
                        break;
                }

                Console.ReadLine();
            }
        }

        private static (DateTime Begin, DateTime End, Activity Activity) EnterExercise()
        {
            Console.Write("Enter the name of the exercise: ");
            var name = Console.ReadLine();

            var energy = ParseDouble("energy consumption per minute");

            var begin = ParseDateTime("exercise start");
            var end = ParseDateTime("end of exercise");

            var activity = new Activity(name, energy);
            return (begin, end, activity);
        }

        private static (Food Food, double Weight) EnterEating()
        {
            Console.Write("Enter the name of the product: ");
            var food = Console.ReadLine();

            var calories = ParseDouble("caloric");
            var prots = ParseDouble("proteins");
            var fats = ParseDouble("fats");
            var carbs = ParseDouble("carbohydrates");

            var weight = ParseDouble("serving weight");
            var product = new Food(food, calories, prots, fats, carbs);


            return (Food: product, Weight: weight);
        }

        private static DateTime ParseDateTime(string value)
        {
            DateTime birthDate;

            while (true)
            {
                Console.Write($"Enter {value} (dd.MM.yyyy): ");
                if (DateTime.TryParse(Console.ReadLine(), out birthDate))
                {
                    break;
                }
                else
                {
                    Console.WriteLine($"Incorrect format {value}");
                }
            }

            return birthDate;
        }

        private static double ParseDouble(string name)
        {
            while (true)
            {
                Console.Write($"Enter {name}: ");
                if (double.TryParse(Console.ReadLine(), out double value))
                {
                    return value;
                }
                else
                {
                    Console.WriteLine($"Incorrect format {name}");
                }
            }
        }
    }
}

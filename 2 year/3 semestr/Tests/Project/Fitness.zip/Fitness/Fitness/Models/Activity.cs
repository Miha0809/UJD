﻿using System;
using System.Collections.Generic;

namespace Fitness.Models
{
    [Serializable]
    public class Activity
    {
        public string Name { get; set; }

        public double CaloriesPerMinute { get; set; }

        public virtual ICollection<Exercise> Exercises { get; set; }

        public Activity() { }

        public Activity(string name, double caloriesPerMinute)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("The name cannot be empty.", nameof(name));
            }

            if (caloriesPerMinute < 0)
            {
                throw new InvalidOperationException($"{nameof(caloriesPerMinute)} Cannot be < 0");
            }

            Name = name;
            CaloriesPerMinute = caloriesPerMinute;
        }

        public override string ToString() => "Activity {\n" +
                                             $"Name: {Name}\n" +
                                             $"CaloriesPerMinute: {CaloriesPerMinute}\n" +
                                             $"\t{Exercises}\n" +
                                             "}\n";
    }
}

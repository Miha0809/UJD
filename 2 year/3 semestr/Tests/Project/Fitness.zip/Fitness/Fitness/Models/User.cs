﻿using System;
using System.Collections.Generic;

namespace Fitness.Models
{
    [Serializable]
    public class User
    {
        public string Name { get; set; }

        public DateTime Birthday { get; set; } = DateTime.Now;
        
        public double Weight { get; set; }
        public double Height { get; set; }

        public int Age { get { return DateTime.Now.Year - Birthday.Year; } }
        
        public virtual Gender Gender { get; set; }

        public virtual ICollection<Eating> Eatings { get; set; }
        public virtual ICollection<Exercise> Exercises { get; set; }

        public User() { }

        public User(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("The username cannot be empty or null.", nameof(name));
            }

            Name = name;
        }

        public User(string name,
                    Gender gender,
                    DateTime birthday,
                    double weight,
                    double height)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("The username cannot be empty or null", nameof(name));
            }

            if (gender == null)
            {
                throw new ArgumentNullException("Gender can't be null.", nameof(gender));
            }

            if (birthday < DateTime.Parse("01.01.1900") || birthday >= DateTime.Now)
            {
                throw new ArgumentException("Impossible date of birth.", nameof(birthday));
            }

            if (weight <= 0)
            {
                throw new ArgumentException("The weight cannot be less than or equal to zero.", nameof(weight));
            }

            if (height <= 0)
            {
                throw new ArgumentException("Growth cannot be less than or equal to zero.", nameof(height));
            }

            Name = name;
            Gender = gender;
            Birthday = birthday;
            Weight = weight;
            Height = height;
        }


        public override string ToString() => "User {\n" +
                                             $"Name: {Name}\n" +
                                             $"Birthday: {Birthday}\n" +
                                             $"Weight: {Weight}\n" +
                                             $"Height: {Height}\n" +
                                             $"Age: {Age}\n" +
                                             $"\t{Gender}\n" +
                                             "}\n";
    }
}

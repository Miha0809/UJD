﻿using System;

namespace Fitness.Models
{
    [Serializable]
    public class Exercise
    {
        public DateTime Start { get; set; }
        public DateTime Finish { get; set; }

        public virtual Activity Activity { get; set; }
        public virtual User User { get; set; }

        public Exercise() { }

        public Exercise(DateTime start, DateTime finish, Activity activity, User user)
        {
            if (finish <  start)
            {
                throw new Exception("The finish cannot start earlier than the start.");
            }

            Start = start;
            Finish = finish;
            Activity = activity ?? throw new ArgumentNullException("The activity cannot be empty.", nameof(activity));
            User = user ?? throw new ArgumentNullException("The user cannot be empty.", nameof(user));
        }

        public override string ToString() => "Exercise {\n" +
                                             $"Start: {Start}\n" +
                                             $"Finish: {Finish}\n" +
                                             $"\t{Activity}\n" +
                                             "}\n";
    }
}

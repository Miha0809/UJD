﻿using System;
using System.Collections.Generic;

namespace Fitness.Models
{
    [Serializable]
    public class Food
    {
        public string Name { get; set; }

        public double Callories { get; set; }
        public double Proteins { get; set; }
        public double Fats { get; set; }
        public double Carbohydates { get; set; }
        public double Carbohydrates { get; set; }
        public double Calories { get; set; }

        public virtual ICollection<Eating> Eatings { get; set; }

        public Food() { }

        public Food(string name) : this(name, 0, 0, 0, 0) { }

        public Food(string name, double callories, double proteins, double fats, double carbohydates)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("The name cannot be empty.", nameof(name));
            }

            if (callories < 0)
            {
                throw new InvalidOperationException($"{nameof(callories)} Cannot be < 0");
            }

            if (proteins < 0)
            {
                throw new InvalidOperationException($"{nameof(proteins)} Cannot be < 0");
            }

            if (fats < 0)
            {
                throw new InvalidOperationException($"{nameof(fats)} Cannot be < 0");
            }

            if (carbohydates < 0)
            {
                throw new InvalidOperationException($"{nameof(carbohydates)} Cannot be < 0");
            }

            Name = name;
            Callories = callories / 100.0;
            Proteins = proteins / 100.0;
            Fats = fats / 100.0;
            Carbohydates = carbohydates / 100.0;
        }

        public override bool Equals(object obj)
        {
            if (obj is Food other)
            {
                return string.Equals(this.Name, other.Name, StringComparison.OrdinalIgnoreCase);
            }

            return false;
        }

        public override string ToString() => "Food {\n" +
                                             $"Name: {Name}\n" +
                                             $"Callories: {Callories}\n" +
                                             $"Proteins: {Proteins}\n" +
                                             $"Fats: {Fats}\n" +
                                             $"Carbohydates: {Carbohydates}\n" +
                                             $"Carbohydrates: {Carbohydrates}\n" +
                                             $"Calories: {Calories}\n" +
                                             $"Eatings: {Eatings}\n" +
                                             "}\n";
    }
}

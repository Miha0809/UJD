﻿using System;
using System.Collections.Generic;

namespace Fitness.Models
{
    [Serializable]
    public class Gender
    {
        public string Name { get; set; }

        public virtual ICollection<User> Users { get; set; }

        public Gender() { }

        public Gender(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("The name cannot be empty.", nameof(name));
            }

            Name = name;
        }

        public override string ToString() => "Gender: {\n" +
                                             $"Name: {Name}\n" +
                                             "}\n";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Fitness.Models
{
    [Serializable]
    public class Eating
    {
        public DateTime Moment { get; set; }

        public Dictionary<Food, double> Foods { get; set; }

        public virtual User User { get; set; }

        public Eating()
        {
            Moment = DateTime.UtcNow;
            Foods = new Dictionary<Food, double>();
        }

        public Eating(User user) : this()
        {
            User = user ?? throw new ArgumentNullException("The user cannot be empty.", nameof(user));
        }

        public void Add(Food food, double weight)
        {
            //var product = Foods.Keys.FirstOrDefault(_food => _food.Equals(food.Name));

            if (food == null)
            {
                throw new ArgumentNullException(nameof(food), "Food cannot be null.");
            }

            if (weight <= 0)
            {
                throw new ArgumentException("Weight must be greater than 0.", nameof(weight));
            }

            if (Foods.ContainsKey(food))
            {
                Foods[food] += weight;
            }
            else
            {
                Foods.Add(food, weight);
            }
        }

        public override string ToString() => $"Eating {{\n" +
                                             $"  Moment: {Moment}\n" +
                                             $"  Foods: {string.Join(", ", Foods.Select(kv => $"{kv.Key.Name} - {kv.Value}g"))}\n" +
                                             $"  User: {User}\n" +
                                             $"}}";
    }
}

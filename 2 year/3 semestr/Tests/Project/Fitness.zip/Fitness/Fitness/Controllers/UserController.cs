﻿using Fitness.Models;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Fitness.Controllers
{
    public class UserController : ControllerBase
    {
        public List<User> Users { get; }
        public User CurrentUser { get; }

        public bool IsNewUser { get; } = false;

        public UserController() { }

        public UserController(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                throw new ArgumentNullException("The username cannot be empty.", nameof(userName));
            }

            Users = GetUsersData();
            CurrentUser = Users.SingleOrDefault(u => u.Name == userName);

            if (CurrentUser == null)
            {
                CurrentUser = new User(userName);
                Users.Add(CurrentUser);
                IsNewUser = true;
            }
            else
            {
                CurrentUser.Eatings = GetEatingsData();
                CurrentUser.Exercises = GetExercisesData();
            }
        }

        public void SetNewUserData(string genderName, DateTime birthday, double weight = 1, double height = 1)
        {
            if (string.IsNullOrWhiteSpace(genderName))
            {
                throw new ArgumentNullException("The gender name cannot be empty or null", nameof(genderName));
            }

            if (birthday < DateTime.Parse("01.01.1900") || birthday >= DateTime.Now)
            {
                throw new ArgumentException("Impossible date of birth.", nameof(birthday));
            }

            if (weight <= 0)
            {
                throw new ArgumentException("The weight cannot be less than or equal to zero.", nameof(weight));
            }

            if (height <= 0)
            {
                throw new ArgumentException("Growth cannot be less than or equal to zero.", nameof(height));
            }

            CurrentUser.Gender = new Gender(genderName);
            CurrentUser.Birthday = birthday;
            CurrentUser.Weight = weight;
            CurrentUser.Height = height;

            Save();
        }

        private List<User> GetUsersData()
        {
            return Load<User>() ?? new List<User>();
        }

        private List<Eating> GetEatingsData()
        {
            var eatingController = new EatingController(CurrentUser);
            return eatingController.Eatings;
        }

        private List<Exercise> GetExercisesData()
        {
            var exerciseController = new ExerciseController(CurrentUser);
            return exerciseController.Exercises;
        }

        private void Save()
        {
            Save(Users);
        }
    }
}

﻿using Fitness.Models;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Fitness.Controllers
{
    public class EatingController : ControllerBase
    {
        private readonly User user;

        public List<Food> Foods { get; }
        public List<Eating> Eatings { get; }
        public Eating Eating { get; }

        public EatingController(User user)
        {
            this.user = user ?? throw new ArgumentNullException("The user cannot be empty.", nameof(user));
            Foods = GetAllFoods();
            Eating = GetEating();
            Eatings = GetAllEatings();
        }

        public void Add(Food food, double weight)
        {
            var product = Foods.SingleOrDefault(f => f.Name.Equals(food.Name));

            if (product == null)
            {
                Foods.Add(food);
                Eating.Add(food, weight);
                Save();
            }
            else
            {
                Eating.Add(product, weight);
                Save();
            }
        }

        private Eating GetEating()
        {
            return Load<Eating>().FirstOrDefault() ?? new Eating(user);
        }

        private List<Food> GetAllFoods()
        {
            return Load<Food>() ?? new List<Food>();
        }

        private List<Eating> GetAllEatings()
        {
            return Load<Eating>() ?? new List<Eating>();
        }

        private void Save()
        {
            Save(Foods);
            Save(new List<Eating>() { Eating });
        }
    }
}

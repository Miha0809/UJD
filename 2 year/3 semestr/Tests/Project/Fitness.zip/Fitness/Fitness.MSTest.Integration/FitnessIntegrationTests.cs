﻿using Fitness.Controllers;
using Fitness.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Fitness.MSTest.Integration
{
    [TestClass]
    public class FitnessIntegrationTests
    {
        [TestMethod]
        public void UserController_SetNewUserData_ShouldUpdateUserInformation()
        {
            // Arrange
            var userName = Guid.NewGuid().ToString();
            var genderName = Guid.NewGuid().ToString();
            var userController = new UserController(userName);

            // Act
            userController.SetNewUserData(genderName, new DateTime(1990, 1, 1), 70, 180);

            // Assert
            var updatedUser = userController.Users.Find(u => u.Name == userName);
            Assert.IsNotNull(updatedUser);
            Assert.AreEqual(genderName, updatedUser.Gender.Name);
            Assert.AreEqual(new DateTime(1990, 1, 1), updatedUser.Birthday);
            Assert.AreEqual(70, updatedUser.Weight);
            Assert.AreEqual(180, updatedUser.Height);
        }

        [TestMethod]
        public void EatingController_Add_ShouldAddFoodToEating()
        {
            // Arrange
            var userName = Guid.NewGuid().ToString();
            var user = new User(userName);
            var eatingController = new EatingController(user);
            var food1 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood1") ?? new Food("TestFood1");
            var food2 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood2") ?? new Food("TestFood2");
            var food3 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood3") ?? new Food("TestFood3");
            var food4 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood4") ?? new Food("TestFood4");
            var food5 = eatingController.Foods.FirstOrDefault(f => f.Name == "TestFood5") ?? new Food("TestFood5");
            var eating = eatingController.Eating;
            var food1Exists = false;
            var food2Exists = false;
            var food3Exists = false;
            var food4Exists = false;
            var food5Exists = false;

            // Act
            eatingController.Add(food1, 150);
            eatingController.Add(food2, 120);
            eatingController.Add(food3, 170);
            eatingController.Add(food4, 190);
            eatingController.Add(food5, 290);

            food1Exists = eating.Foods.TryGetValue(food1, out var quantity1);
            food2Exists = eating.Foods.TryGetValue(food2, out var quantity2);
            food3Exists = eating.Foods.TryGetValue(food3, out var quantity3);
            food4Exists = eating.Foods.TryGetValue(food4, out var quantity4);
            food5Exists = eating.Foods.TryGetValue(food5, out var quantity5);

            // Assert
            Assert.IsTrue(food1Exists, $"Food '{food1.Name}' not found in the dictionary.");
            Assert.AreEqual(150, quantity1);
            Assert.IsTrue(food2Exists, $"Food '{food2.Name}' not found in the dictionary.");
            Assert.AreEqual(120, quantity2);
            Assert.IsTrue(food3Exists, $"Food '{food3.Name}' not found in the dictionary.");
            Assert.AreEqual(170, quantity3);
            Assert.IsTrue(food4Exists, $"Food '{food4.Name}' not found in the dictionary.");
            Assert.AreEqual(190, quantity4);
            Assert.IsTrue(food5Exists, $"Food '{food5.Name}' not found in the dictionary.");
            Assert.AreEqual(290, quantity5);
        }

        [TestMethod]
        public void ExerciseController_Add_ShouldAddExerciseToExercises()
        {
            // Arrange
            var userName = Guid.NewGuid().ToString();
            var user = new User(userName);
            var exerciseController = new ExerciseController(user);
            var activityName = Guid.NewGuid().ToString();
            var caloriesPerMinute = 12;
            var activity = new Activity(activityName, caloriesPerMinute);
            var beginTime = DateTime.Now.AddHours(-1);
            var endTime = DateTime.Now;

            // Act
            exerciseController.Add(activity, beginTime, endTime);

            // Assert
            Assert.AreEqual(activity, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Activity);
            Assert.AreEqual(activityName, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Activity.Name);
            Assert.AreEqual(caloriesPerMinute, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Activity.CaloriesPerMinute);
            Assert.AreEqual(user, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).User);
            Assert.AreEqual(beginTime, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Start);
            Assert.AreEqual(endTime, exerciseController.Exercises.FirstOrDefault(a => a.Activity.Name.Equals(activityName)).Finish);
        }
    }
}

﻿using Fitness.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Fitness.MSTest.Unit.Controllers
{
    [TestClass]
    public class UserControllerTest
    {
        [TestMethod()]
        public void UserController_SetNewUserData_ShouldAddUserData()
        {
            // Arrange
            var userName = Guid.NewGuid().ToString();
            var birthday = DateTime.Now.AddYears(-18);
            var weight = 90;
            var height = 190;
            var gender = "man";
            var userController = new UserController(userName);
            UserController userController2;

            // Act
            userController.SetNewUserData(gender, birthday, weight, height);
            userController2 = new UserController(userName);

            // Assert
            Assert.AreEqual(userName, userController2.CurrentUser.Name);
            Assert.AreEqual(birthday, userController2.CurrentUser.Birthday);
            Assert.AreEqual(weight, userController2.CurrentUser.Weight);
            Assert.AreEqual(height, userController2.CurrentUser.Height);
            Assert.AreEqual(gender, userController2.CurrentUser.Gender.Name);
        }

        [TestMethod()]
        public void UserController_SaveUserData_ShouldSaveToFileUserData()
        {
            // Arrange
            var userName = Guid.NewGuid().ToString();

            // Act
            var controller = new UserController(userName);

            // Assert
            Assert.AreEqual(userName, controller.CurrentUser.Name);
        }
    }
}

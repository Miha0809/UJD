﻿using Fitness.Controllers;
using Fitness.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Fitness.MSTest.Unit.Controllers
{
    [TestClass]
    public class EatingControllerTest
    {
        [TestClass()]
        public class EatingControllerTests
        {
            [TestMethod()]
            public void EatingController_AddNewEatingData_ShouldAddNewEating()
            {
                // Arrange
                var userName = Guid.NewGuid().ToString();
                var foodName = Guid.NewGuid().ToString();
                var rnd = new Random();
                var userController = new UserController(userName);
                var eatingController = new EatingController(userController.CurrentUser);
                var food = new Food(foodName, rnd.Next(50, 500), rnd.Next(50, 500), rnd.Next(50, 500), rnd.Next(50, 500));

                // Act
                eatingController.Add(food, 100);

                // Assert
                Assert.AreEqual(food.Name, eatingController.Eating.Foods.FirstOrDefault(f => f.Key.Name.Equals(foodName)).Key.Name);
            }
        }
    }
}

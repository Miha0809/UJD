﻿using Fitness.Controllers;
using Fitness.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Fitness.MSTest.Unit.Controllers
{
    [TestClass]
    public class ExerciseControllerTest
    {
        [TestMethod()]
        public void ExerciseController_AddNewExerciseData_ShouldAddNewExercise()
        {
            // Arrange
            var userName = Guid.NewGuid().ToString();
            var activityName = Guid.NewGuid().ToString();
            var rnd = new Random();
            var userController = new UserController(userName);
            var exerciseController = new ExerciseController(userController.CurrentUser);
            var activity = new Activity(activityName, rnd.Next(10, 50));

            // Act
            exerciseController.Add(activity, DateTime.Now, DateTime.Now.AddHours(1));

            // Assert
            Assert.AreEqual(activityName, exerciseController.Activities.FirstOrDefault(a => a.Name.Equals(activityName)).Name);
        }
    }
}
